package com.cbc.android;

import android.content.Intent;

public class IntentHandler {
    private Intent intent;

    public IntentHandler(Intent intent) {
        this.intent = intent;
    }
    public IntentHandler() {
        this(new Intent());
    }
    public Intent getIntent() {
        return intent;
    }
    public <T extends Enum<T>> T enumValueOf(Class<T> enumType, String value) {
        if (value == null) return null;

        return Enum.valueOf(enumType, value);
    }
    public <T extends Enum<T>> T enumValueOfExtra(Class<T> enumType, String value) {
        return enumValueOf(enumType, intent.getStringExtra(value));
    }
    public String getAction() {
        return intent.getAction();
    }
    public String getStringExtra(String value) {
        return intent.getStringExtra(value);
    }
}
