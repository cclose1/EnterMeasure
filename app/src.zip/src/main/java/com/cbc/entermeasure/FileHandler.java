package com.cbc.entermeasure;

import android.app.Activity;

public class FileHandler extends Activity {
}
