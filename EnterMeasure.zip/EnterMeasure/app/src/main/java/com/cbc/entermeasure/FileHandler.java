package com.cbc.entermeasure;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.annotation.Nullable;

import com.cbc.android.EditTextHandler;
import com.cbc.android.IntentHandler;
import com.cbc.android.SpinnerHandler;

public class FileHandler extends Activity {
    static public String REQUEST      = "com.cbc.entermeasure.request";
    static public String STORAGE_TYPE = "com.cbc.entermeasure.storagetype";

    public enum Request     {GetFile, GetPath}
    public enum StorageType {Local, Media, External}

    private IntentHandler   intent;
    private Request         request;
    private EditTextHandler etRequest     = null;
    private SpinnerHandler  spStorageType = null;

    public void onComplete(View view) {
        Intent data = new Intent();

        data.putExtra(FileHandler.REQUEST, request.toString());
        setResult(RESULT_OK, data);
        finish();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_file_handler);
        etRequest     = new EditTextHandler(findViewById(R.id.request));
        spStorageType = new SpinnerHandler(findViewById(R.id.storageType), Request.class);
        intent        = new IntentHandler(getIntent());
        request       = intent.getEnumAction(Request.class);
        etRequest.setText(request.toString());
    }


}
